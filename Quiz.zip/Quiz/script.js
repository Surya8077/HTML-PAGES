// Questions (0-based answer index)
const questions = [
  { q: "HTML stands for?", o: ["Hyper Text Markup Language", "High Tech Modern Language", "Highly Transform Medium Language"], a: 0 },
  { q: "Tool used for phishing?", o: ["Zphisher", "Kphisher", "Nphisher"], a: 0 },
  { q: "RF gadget like jammer?", o: ["Rubber Ducky", "Flipper Zero", "5.6 GHz Dongle"], a: 1 },
  { q: "JavaScript tag?", o: ["js", "javascript", "script", "code"], a: 2 },
  { q: "CSS stands for?", o: ["Creative Style System", "Cascading Style Sheets", "Colorful Style Sheets", "Computer Style Sheets"], a: 1 },
  { q: "JS stands for?", o: ["JavaScript", "Jvren Script", "Joint Script"], a: 0 }
];

let i = 0, score = 0, time = 5, timer, pick = null;

const $ = id => document.getElementById(id);
const start = $("start-screen"), quiz = $("quiz-screen"), result = $("results-screen");
const qEl = $("question"), oEl = $("options"), tEl = $("timer");
const next = $("next-btn"), fs = $("final-score"), bar = $("progress-bar");

$("start-btn").onclick = () => (start.hidden = true, quiz.hidden = false, load());
$("restart-btn").onclick = () => location.reload();
next.onclick = nextQ;

function load() {
  clearInterval(timer);
  time = 5; pick = null; next.disabled = true;
  const { q, o } = questions[i];
  qEl.textContent = q;
  oEl.innerHTML = o.map((x, n) =>
    `<div class="option" onclick="pickOpt(${n},this)">${x}</div>`
  ).join("");
  bar.style.width = ((i + 1) / questions.length) * 100 + "%";
  tick();
}

function tick() {
  tEl.textContent = time;
  timer = setInterval(() => {
    if (--time < 0) return nextQ();
    tEl.textContent = time;
  }, 1000);
}

function pickOpt(n, el) {
  document.querySelectorAll(".option").forEach(x => x.classList.remove("selected"));
  el.classList.add("selected");
  pick = n; next.disabled = false;
}

function nextQ() {
  clearInterval(timer);
  if (pick === questions[i].a) score++;
  if (++i < questions.length) load();
  else {
    quiz.hidden = true; result.hidden = false;
    fs.textContent = `Score: ${score}/${questions.length}`;
  }
}
